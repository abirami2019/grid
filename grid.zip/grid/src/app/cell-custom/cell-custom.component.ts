import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cell-custom',
  templateUrl: './cell-custom.component.html',
  styleUrls: ['./cell-custom.component.css']
})
export class CellCustomComponent implements OnInit {

  
  constructor() { }

  agInit(params:any){
   
  }

  ngOnInit() {
  }

  HideEditButton(){
    
  }

}
