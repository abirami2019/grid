import { Component,OnInit, ViewEncapsulation } from '@angular/core';
import { CellCustomComponent } from './cell-custom/cell-custom.component';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation:ViewEncapsulation.None
})
export class AppComponent implements OnInit{

  model_items:any  = [];
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  gridApi: any;
  gridColumnApi:any;
  ngOnInit() {
    this.dropdownList = [
      { item_id: 1, item_text: 'model1' },
      { item_id: 2, item_text: 'model2' },
      { item_id: 3, item_text: 'model3' },
      { item_id: 4, item_text: 'model4' },
      { item_id: 5, item_text: 'model5' },
      { item_id: 6, item_text: 'model6' },
      { item_id: 7, item_text: 'model7' },
      { item_id: 8, item_text: 'model8' },
      { item_id: 9, item_text: 'model9' },
      { item_id: 10, item_text: 'model10' }
    ];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      itemsShowLimit: 5,
      allowSearchFilter: true,
      enableCheckAll:false
    };

  }
  
  onGridReady(params) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
  }

  columnDefs = [
    {headerName: 'Make', field: 'make',pinned:"left"}, 
    {headerName: 'Price', field: 'price',pinned:"right"},
    {headerName:'Actions', field:'actions',pinned:"right",cellRendererFramework:CellCustomComponent},
    {headerName: 'Model', field: 'model'}
  ];
 
  rowData=[];
  onItemSelect(item: any) {
    this.model_items=item;
    console.log(item);
      this.columnDefs.push({headerName: item.item_text, field: item.item_text});
      this.rowData.push("poorni");
      this.gridApi.setColumnDefs(this.columnDefs);
  }
  // onSelectAll(items: any) {
  //   console.log(items);
  //   for(var i=0;items;i++){  
  //     this.columnDefs.push({headerName: items[i].item_text, field: items[i].item_text,pinned: "left",resizable: true});
  //     this.gridApi.setColumnDefs(this.columnDefs);
  //   }
 // }
 
  title = 'my-project';
//   columnDefs = [
//     {headerName: 'Make', field: 'make',pinned: "left",resizable: true}, 
   
//     {headerName: 'Model1', field: 'model1'},
//       {headerName: 'Model2', field: 'model2'},
//       {headerName: 'Model3', field: 'model3'},
//       {headerName: 'Model4', field: 'model4'},
//       {headerName: 'Model5', field: 'model5'},
//       {headerName: 'Model6', field: 'model6'},
//       {headerName: 'Model7', field: 'model7'},
//       {headerName: 'Model8', field: 'model8'},
//       {headerName: 'Model9', field: 'model9'},
//       {headerName: 'Model10', field: 'model10'},
//     {headerName: 'Price', field: 'price',  editable: true,pinned: "right"},
//     {headerName:'Actions', field:'actions',pinned: "right",
//     cellRendererFramework:CellCustomComponent,
  
//    }
// ];

// rowData = [
//     {make: 'Toyota ygfcgbdxcnjh dyihfcgbdhdx isdjcbfgyxdnhcb xncdhxvcbdv  dhcjvdbxnmcb d dhcjbdn dyihcbduyibxsc iausdgbcnskxc  askdchbsnxcnkasd ajksdxbn jasdbdcnsx jzsbhxcn',
//      model1: 'Celica', model2: 'Celica', model3: 'Celica', model4: 'Celica', model5: 'Celica', model6: 'Celica', model7: 'Celica', model8: 'Celica', model9: 'Celica', model10: 'Celica', price: 35000},
//     {make: 'Ford', model1: 'Mondeo', price: 32000},
//     {make: 'Porsche', model1: 'Boxter', price: 72000}
// ];

}
